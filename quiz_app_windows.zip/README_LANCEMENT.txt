QUIZ APP WINDOWS\r\n\r\n1) Double-cliquer sur hamza_tahiri_et_marwan_ouali.exe\r\n2) Repondre a: Tu es pret ?\r\n3) Jouer le quiz\r\n\r\nAucune installation requise.\r\n
